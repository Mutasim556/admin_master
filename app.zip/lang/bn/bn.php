<?php
return array (
    // 'Admin Profile' => 'অ্যাডমিন প্রোফাইল',
    // 'My Profile' => 'আমার প্রোফাইল',
);
